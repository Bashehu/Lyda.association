<?php
$name = $_POST['name'];
$visitor_email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$email_address = $_POST['email_address'];
$phone_number = $_POST['phone_number'];
$comment = $_POST['comment'];

$email_from = 'babashehuabba@gmail.com';

$email_subject = 'new form submission';

$email_body = "User Name : $name.\n".
                "User email : $visitor_email.\n".
                "User subject : $subject.\n".
                "User message : $message.\n".
                "User first name : $first_name.\n".
                "User last name : $last_name.\n".
                "User email_address : $email_address.\n".
                "User phone : $phone_number.\n".
                "User comment : $comment.\n";


$to = 'babashehuabba@gmail.com';

      $headers = "From: $email_from \r\n";

      $headers .= "Reply_To: $visitor_email \r\n";

      mail($to,$email_subject,$email_body, $headers);

      header("Location: contact.html, registration.html");


?>